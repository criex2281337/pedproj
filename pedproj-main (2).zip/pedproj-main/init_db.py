import sqlite3
import bcrypt
from datetime import datetime, timedelta
import json
import random

def init_database():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    # Таблица пользователей (обновленная версия с полями is_active и is_admin)
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username VARCHAR(80) UNIQUE NOT NULL,
            email VARCHAR(120) UNIQUE NOT NULL,
            password_hash VARCHAR(128) NOT NULL,
            xp INTEGER DEFAULT 0,
            streak INTEGER DEFAULT 0,
            last_login DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            target_language VARCHAR(50) DEFAULT 'Английский',
            native_language VARCHAR(50) DEFAULT 'Русский',
            is_active BOOLEAN DEFAULT TRUE,
            is_admin BOOLEAN DEFAULT FALSE
        )
    ''')
    
    # Таблица языков
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS languages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(50) NOT NULL,
            code VARCHAR(5) NOT NULL,
            flag_emoji VARCHAR(10)
        )
    ''')
    
    # Таблица уроков
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS lessons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            language_id INTEGER,
            title VARCHAR(100) NOT NULL,
            description TEXT,
            level INTEGER DEFAULT 1,
            order_index INTEGER,
            xp_reward INTEGER DEFAULT 10,
            FOREIGN KEY (language_id) REFERENCES languages (id)
        )
    ''')
    
    # Таблица упражнений
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS exercises (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lesson_id INTEGER,
            type VARCHAR(20) NOT NULL,
            question TEXT NOT NULL,
            correct_answer TEXT NOT NULL,
            options TEXT,
            audio_file VARCHAR(100),
            explanation TEXT,
            order_index INTEGER,
            FOREIGN KEY (lesson_id) REFERENCES lessons (id)
        )
    ''')
    
    # Таблица прогресса пользователя
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            lesson_id INTEGER,
            completed BOOLEAN DEFAULT FALSE,
            score INTEGER DEFAULT 0,
            completed_at TIMESTAMP,
            attempts INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (lesson_id) REFERENCES lessons (id)
        )
    ''')
    
    # Таблица ответов пользователя
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            exercise_id INTEGER,
            user_answer TEXT,
            is_correct BOOLEAN,
            answered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (exercise_id) REFERENCES exercises (id)
        )
    ''')

    # Добавляем администратора
    admin_password_hash = bcrypt.hashpw('admin123'.encode('utf-8'), bcrypt.gensalt())
    cursor.execute('''
        INSERT OR IGNORE INTO users (username, email, password_hash, is_admin)
        VALUES (?, ?, ?, ?)
    ''', ('admin', 'admin@lingualearn.com', admin_password_hash, True))

    print("Администратор создан: admin / admin123")
    
    # Добавляем языки
    languages = [
        ('Английский', 'en', '🇺🇸'),
        ('Испанский', 'es', '🇪🇸'),
        ('Французский', 'fr', '🇫🇷'),
        ('Немецкий', 'de', '🇩🇪'),
        ('Итальянский', 'it', '🇮🇹'),
        ('Португальский', 'pt', '🇵🇹'),
        ('Русский', 'ru', '🇷🇺')
    ]
    
    cursor.executemany(
        'INSERT OR IGNORE INTO languages (name, code, flag_emoji) VALUES (?, ?, ?)',
        languages
    )
    
    # Добавляем интересные уроки для английского
    english_id = 1
    lessons_data = [
        (english_id, '🎯 Основы общения', 'Начни говорить с первых минут!', 1, 1, 15),
        (english_id, '🍕 Еда и ресторан', 'Закажи еду как настоящий англичанин', 1, 2, 20),
        (english_id, '🚗 Путешествия', 'Говори свободно в аэропорту и отеле', 1, 3, 25),
        (english_id, '💼 Работа и бизнес', 'Деловой английский для карьеры', 2, 4, 30),
        (english_id, '❤️ Знакомства', 'Найди друзей и любовь на английском', 2, 5, 25),
        (english_id, '🎬 Фильмы и сериалы', 'Смотри кино без субтитров', 2, 6, 30),
        (english_id, '🏥 Здоровье', 'Объясни врачу что болит', 3, 7, 35),
        (english_id, '💰 Деньги и шопинг', 'Покупай с умом за границей', 3, 8, 30),
        (english_id, '🎉 Хобби и увлечения', 'Расскажи о своих интересах', 3, 9, 35),
        (english_id, '🌍 Культура', 'Пойми менталитет англичан', 4, 10, 40),
    ]
    
    cursor.executemany(
        'INSERT OR IGNORE INTO lessons (language_id, title, description, level, order_index, xp_reward) VALUES (?, ?, ?, ?, ?, ?)',
        lessons_data
    )
    
    # Добавляем упражнения с интересными фразами и ситуациями
    exercises_data = [
        # Урок 1: Основы общения
        (1, 'learning', 'Hello!', 'Привет!', '["Привет!", "Пока!", "Спасибо!", "Извините!"]', None, 'Самое популярное приветствие в мире 🌍', 1),
        (1, 'learning', 'How are you?', 'Как дела?', '["Как дела?", "Как тебя зовут?", "Откуда ты?", "Сколько времени?"]', None, 'Вежливый вопрос о самочувствии 🤔', 2),
        (1, 'learning', 'I\'m fine, thanks!', 'У меня все хорошо, спасибо!', '["У меня все хорошо, спасибо!", "Я устал", "Я голоден", "Я заблудился"]', None, 'Стандартный положительный ответ 😊', 3),
        (1, 'learning', 'What\'s your name?', 'Как тебя зовут?', '["Как тебя зовут?", "Сколько тебе лет?", "Где ты живешь?", "Что ты делаешь?"]', None, 'Вопрос для знакомства 👋', 4),
        (1, 'learning', 'My name is...', 'Меня зовут...', '["Меня зовут...", "Я из...", "Мне ... лет", "Я работаю..."]', None, 'Представление себя 🎭', 5),
        (1, 'learning', 'Nice to meet you!', 'Приятно познакомиться!', '["Приятно познакомиться!", "До свидания!", "Извините!", "Пожалуйста!"]', None, 'Вежливая фраза при знакомстве 🤝', 6),
        
        (1, 'practice', 'Как поздороваться с другом?', 'Hello!', '["Hello!", "Goodbye!", "Sorry!", "Please!"]', None, 'Hello - универсальное приветствие 👋', 7),
        (1, 'practice', 'Что ответить на "How are you?"', 'I\'m fine, thanks!', '["I\'m fine, thanks!", "My name is...", "I am from...", "I am 25 years old"]', None, 'I\'m fine, thanks! - вежливый ответ 👍', 8),
        (1, 'practice', 'Как спросить имя человека?', 'What\'s your name?', '["What\'s your name?", "How are you?", "Where are you from?", "What time is it?"]', None, 'What\'s your name? - вопрос об имени 🏷️', 9),
        (1, 'practice', 'Как представиться?', 'My name is...', '["My name is...", "I live in...", "I like...", "I work as..."]', None, 'My name is... - начало представления 🎯', 10),
        (1, 'practice', 'Что сказать при знакомстве?', 'Nice to meet you!', '["Nice to meet you!", "See you later!", "Thank you!", "Good luck!"]', None, 'Nice to meet you! - вежливость при знакомстве 🤗', 11),
        
        # Урок 2: Еда и ресторан
        (2, 'learning', 'I\'m hungry', 'Я голоден', '["Я голоден", "Я хочу пить", "Я устал", "Я счастлив"]', None, 'Выражение голода 🍔', 1),
        (2, 'learning', 'Menu, please', 'Меню, пожалуйста', '["Меню, пожалуйста", "Счет, пожалуйста", "Воду, пожалуйста", "Кофе, пожалуйста"]', None, 'Просьба меню в ресторане 📋', 2),
        (2, 'learning', 'I\'d like to order', 'Я бы хотел заказать', '["Я бы хотел заказать", "Я бы хотел оплатить", "Я бы хотел уйти", "Я бы хотел остаться"]', None, 'Вежливая фраза для заказа 🍽️', 3),
        (2, 'learning', 'This is delicious!', 'Это очень вкусно!', '["Это очень вкусно!", "Это слишком соленое", "Это холодное", "Это горячее"]', None, 'Комплимент повару 👨‍🍳', 4),
        (2, 'learning', 'Bill, please', 'Счет, пожалуйста', '["Счет, пожалуйста", "Меню, пожалуйста", "Вилку, пожалуйста", "Нож, пожалуйста"]', None, 'Просьба счета 💰', 5),
        (2, 'learning', 'Can I have water?', 'Можно мне воды?', '["Можно мне воды?", "Можно мне соль?", "Можно мне хлеб?", "Можно мне салфетку?"]', None, 'Вежливая просьба напитка 🚰', 6),
        
        (2, 'practice', 'Как сказать что ты голоден?', 'I\'m hungry', '["I\'m hungry", "I\'m thirsty", "I\'m tired", "I\'m happy"]', None, 'I\'m hungry - выражение голода 🍕', 7),
        (2, 'practice', 'Как попросить меню?', 'Menu, please', '["Menu, please", "Bill, please", "Water, please", "Coffee, please"]', None, 'Menu, please - просьба меню 📖', 8),
        (2, 'practice', 'Как сделать заказ?', 'I\'d like to order', '["I\'d like to order", "I\'d like to pay", "I\'d like to leave", "I\'d like to stay"]', None, 'I\'d like to order - вежливый заказ ✅', 9),
        (2, 'practice', 'Как похвалить еду?', 'This is delicious!', '["This is delicious!", "This is terrible!", "This is cold!", "This is expensive!"]', None, 'This is delicious! - комплимент еде 😋', 10),
        (2, 'practice', 'Как попросить счет?', 'Bill, please', '["Bill, please", "Menu, please", "Water, please", "Salt, please"]', None, 'Bill, please - просьба счета 🧾', 11),
        
        # Урок 3: Путешествия
        (3, 'learning', 'Where is the airport?', 'Где находится аэропорт?', '["Где находится аэропорт?", "Где находится вокзал?", "Где находится отель?", "Где находится музей?"]', None, 'Вопрос о местоположении аэропорта ✈️', 1),
        (3, 'learning', 'I need a taxi', 'Мне нужнo такси', '["Мне нужно такси", "Мне нужен автобус", "Мне нужен поезд", "Мне нужна карта"]', None, 'Просьба такси 🚕', 2),
        (3, 'learning', 'How much is it?', 'Сколько это стоит?', '["Сколько это стоит?", "Что это?", "Где это?", "Когда это?"]', None, 'Вопрос о цене 💵', 3),
        (3, 'learning', 'I\'m lost', 'Я заблудился', '["Я заблудился", "Я устал", "Я голоден", "Я спешу"]', None, 'Признание что потерялся 🗺️', 4),
        (3, 'learning', 'Can you help me?', 'Вы можете мне помочь?', '["Вы можете мне помочь?", "Вы говорите по-русски?", "Который час?", "Где туалет?"]', None, 'Вежливая просьба о помощи 🆘', 5),
        (3, 'learning', 'What time does it open?', 'Когда это открывается?', '["Когда это открывается?", "Когда это закрывается?", "Сколько это стоит?", "Где это находится?"]', None, 'Вопрос о времени работы 🕒', 6),
        
        (3, 'practice', 'Как спросить где аэропорт?', 'Where is the airport?', '["Where is the airport?", "Where is the station?", "Where is the hotel?", "Where is the museum?"]', None, 'Where is the airport? - вопрос о местоположении 🛬', 7),
        (3, 'practice', 'Как сказать что нужнo такси?', 'I need a taxi', '["I need a taxi", "I need a bus", "I need a train", "I need a map"]', None, 'I need a taxi - просьба транспорта 🚖', 8),
        (3, 'practice', 'Как спросить цену?', 'How much is it?', '["How much is it?", "What is it?", "Where is it?", "When is it?"]', None, 'How much is it? - вопрос о стоимости 💰', 9),
        (3, 'practice', 'Как сказать что потерялся?', 'I\'m lost', '["I\'m lost", "I\'m tired", "I\'m hungry", "I\'m in a hurry"]', None, 'I\'m lost - признание что заблудился 🗿', 10),
        (3, 'practice', 'Как попросить помощи?', 'Can you help me?', '["Can you help me?", "Do you speak Russian?", "What time is it?", "Where is the toilet?"]', None, 'Can you help me? - вежливая просьба о помощи 🙏', 11),
        
        # Урок 4: Работа и бизнес
        (4, 'learning', 'I work as a manager', 'Я работаю менеджером', '["Я работаю менеджером", "Я работаю программистом", "Я работаю учителем", "Я работаю врачом"]', None, 'Рассказ о профессии 💼', 1),
        (4, 'learning', 'Let\'s schedule a meeting', 'Давайте назначим встречу', '["Давайте назначим встречу", "Давайте пообедаем", "Давайте пойдем домой", "Давайте начнем"]', None, 'Предложение о встрече 📅', 2),
        (4, 'learning', 'I agree with you', 'Я согласен с вами', '["Я согласен с вами", "Я не согласен", "Я не понимаю", "Я сомневаюсь"]', None, 'Выражение согласия 👍', 3),
        (4, 'learning', 'Could you send me the file?', 'Не могли бы вы отправить мне файл?', '["Не могли бы вы отправить мне файл?", "Не могли бы вы помочь?", "Не могли бы вы объяснить?", "Не могли бы вы повторить?"]', None, 'Вежливая просьба в офисе 📧', 4),
        (4, 'learning', 'When is the deadline?', 'Когда дедлайн?', '["Когда дедлайн?", "Когда встреча?", "Когда обед?", "Когда отпуск?"]', None, 'Вопрос о сроках ⏰', 5),
        (4, 'learning', 'I need more time', 'Мне нужно больше времени', '["Мне нужно больше времени", "Мне нужна помощь", "Мне нужен перерыв", "Мне нужен компьютер"]', None, 'Просьба дополнительного времени 🕐', 6),
        
        (4, 'practice', 'Как сказать о своей работе?', 'I work as a manager', '["I work as a manager", "I work as a programmer", "I work as a teacher", "I work as a doctor"]', None, 'I work as... - рассказ о профессии 👨‍💼', 7),
        (4, 'practice', 'Как предложить встречу?', 'Let\'s schedule a meeting', '["Let\'s schedule a meeting", "Let\'s have lunch", "Let\'s go home", "Let\'s start"]', None, 'Let\'s schedule a meeting - предложение встречи 🤝', 8),
        (4, 'practice', 'Как выразить согласие?', 'I agree with you', '["I agree with you", "I disagree", "I don\'t understand", "I doubt it"]', None, 'I agree with you - выражение согласия ✅', 9),
        (4, 'practice', 'Как вежливо попросить файл?', 'Could you send me the file?', '["Could you send me the file?", "Could you help me?", "Could you explain?", "Could you repeat?"]', None, 'Could you... - вежливая просьба 📨', 10),
        (4, 'practice', 'Как спросить о дедлайне?', 'When is the deadline?', '["When is the deadline?", "When is the meeting?", "When is lunch?", "When is vacation?"]', None, 'When is the deadline? - вопрос о сроках 📆', 11),
        
        # Урок 5: Знакомства
        (5, 'learning', 'You have beautiful eyes', 'У тебя красивые глаза', '["У тебя красивые глаза", "У тебя красивая улыбка", "У тебя красивый голос", "У тебя красивые волосы"]', None, 'Комплимент внешности 😍', 1),
        (5, 'learning', 'Would you like to dance?', 'Хочешь потанцевать?', '["Хочешь потанцевать?", "Хочешь выпить кофе?", "Хочешь погулять?", "Хочешь посмотреть кино?"]', None, 'Приглашение на танец 💃', 2),
        (5, 'learning', 'I really like you', 'Ты мне очень нравишься', '["Ты мне очень нравишься", "Ты мне не нравишься", "Я тебя не понимаю", "Я тебя уважаю"]', None, 'Признание в симпатии ❤️', 3),
        (5, 'learning', 'What do you do for fun?', 'Что ты делаешь для развлечения?', '["Что ты делаешь для развлечения?", "Где ты работаешь?", "Где ты живешь?", "Сколько тебе лет?"]', None, 'Вопрос о хобби 🎮', 4),
        (5, 'learning', 'Can I have your number?', 'Можно твой номер?', '["Можно твой номер?", "Можно твое имя?", "Можно твою фотографию?", "Можно твой адрес?"]', None, 'Просьба номера телефона 📱', 5),
        (5, 'learning', 'Let\'s meet again', 'Давай встретимся еще', '["Давай встретимся еще", "Давай попрощаемся", "Давай поссоримся", "Давай расстанемся"]', None, 'Предложение новой встречи 📞', 6),
        
        (5, 'practice', 'Как сделать комплимент глазам?', 'You have beautiful eyes', '["You have beautiful eyes", "You have a beautiful smile", "You have a beautiful voice", "You have beautiful hair"]', None, 'You have beautiful... - комплимент внешности 👀', 7),
        (5, 'practice', 'Как пригласить на танец?', 'Would you like to dance?', '["Would you like to dance?", "Would you like some coffee?", "Would you like to walk?", "Would you like to watch a movie?"]', None, 'Would you like to... - вежливое приглашение 💫', 8),
        (5, 'practice', 'Как сказать что нравишься?', 'I really like you', '["I really like you", "I don\'t like you", "I don\'t understand you", "I respect you"]', None, 'I really like you - признание в симпатии 💖', 9),
        (5, 'practice', 'Как спросить о хобби?', 'What do you do for fun?', '["What do you do for fun?", "Where do you work?", "Where do you live?", "How old are you?"]', None, 'What do you do for fun? - вопрос об увлечениях 🎯', 10),
        (5, 'practice', 'Как попросить номер телефона?', 'Can I have your number?', '["Can I have your number?", "Can I have your name?", "Can I have your photo?", "Can I have your address?"]', None, 'Can I have your number? - просьба контакта 📲', 11),
        
        # Урок 6: Фильмы и сериалы
        (6, 'learning', 'This movie is amazing!', 'Этот фильм потрясающий!', '["Этот фильм потрясающий!", "Этот фильм ужасный", "Этот фильм скучный", "Этот фильм странный"]', None, 'Восторг от фильма 🎬', 1),
        (6, 'learning', 'Who is your favorite actor?', 'Кто твой любимый актер?', '["Кто твой любимый актер?", "Кто твой любимый режиссер?", "Какой твой любимый фильм?", "Какой твой любимый сериал?"]', None, 'Вопрос о предпочтениях в кино 🎭', 2),
        (6, 'learning', 'I love action movies', 'Я обожаю боевики', '["Я обожаю боевики", "Я ненавижу боевики", "Я не смотрю боевики", "Я редко смотрю боевики"]', None, 'Выражение любви к жанру 💥', 3),
        (6, 'learning', 'Let\'s watch a comedy', 'Давай посмотрим комедию', '["Давай посмотрим комедию", "Давай посмотрим ужасы", "Давай посмотрим драму", "Давай посмотрим фантастику"]', None, 'Предложение посмотреть фильм 🍿', 4),
        (6, 'learning', 'The special effects are incredible', 'Спецэффекты невероятные', '["Спецэффекты невероятные", "Актеры играют плохо", "Сюжет запутанный", "Диалоги скучные"]', None, 'Комментарий о спецэффектах ✨', 5),
        (6, 'learning', 'This scene is emotional', 'Эта сцена очень эмоциональная', '["Эта сцена очень эмоциональная", "Эта сцена смешная", "Эта сцена страшная", "Эта сцена романтическая"]', None, 'Оценка сцены в фильме 🎭', 6),
        
        (6, 'practice', 'Как выразить восторг от фильма?', 'This movie is amazing!', '["This movie is amazing!", "This movie is terrible", "This movie is boring", "This movie is weird"]', None, 'This movie is amazing! - положительная оценка 🎉', 7),
        (6, 'practice', 'Как спросить о любимом актере?', 'Who is your favorite actor?', '["Who is your favorite actor?", "Who is your favorite director?", "What is your favorite movie?", "What is your favorite series?"]', None, 'Who is your favorite... - вопрос о предпочтениях 🌟', 8),
        (6, 'practice', 'Как сказать что любишь боевики?', 'I love action movies', '["I love action movies", "I hate action movies", "I don\'t watch action movies", "I rarely watch action movies"]', None, 'I love... - выражение любви к жанру ❤️', 9),
        (6, 'practice', 'Как предложить посмотреть комедию?', 'Let\'s watch a comedy', '["Let\'s watch a comedy", "Let\'s watch a horror", "Let\'s watch a drama", "Let\'s watch sci-fi"]', None, 'Let\'s watch... - предложение посмотреть фильм 📺', 10),
        (6, 'practice', 'Как похвалить спецэффекты?', 'The special effects are incredible', '["The special effects are incredible", "The actors are bad", "The plot is confusing", "The dialogues are boring"]', None, 'The special effects are... - комментарий о визуальных эффектах 🎇', 11),
        
        # Урок 7: Здоровье
        (7, 'learning', 'I don\'t feel well', 'Я плохо себя чувствую', '["Я плохо себя чувствую", "Я хорошо себя чувствую", "Я устал", "Я голоден"]', None, 'Жалоба на самочувствие 🤒', 1),
        (7, 'learning', 'I have a headache', 'У меня болит голова', '["У меня болит голова", "У меня болит живот", "У меня болит горло", "У меня болят зубы"]', None, 'Описание симптомов 🤕', 2),
        (7, 'learning', 'I need a doctor', 'Мне нужен врач', '["Мне нужен врач", "Мне нужна помощь", "Мне нужны лекарства", "Мне нужен отдых"]', None, 'Просьба медицинской помощи 🏥', 3),
        (7, 'learning', 'Where is the pharmacy?', 'Где находится аптека?', '["Где находится аптека?", "Где находится больница?", "Где находится поликлиника?", "Где находится стоматолог?"]', None, 'Вопрос о местоположении аптеки 💊', 4),
        (7, 'learning', 'I\'m allergic to...', 'У меня аллергия на...', '["У меня аллергия на...", "У меня нет аллергии", "У меня высокое давление", "У меня диабет"]', None, 'Сообщение об аллергии 🚫', 5),
        (7, 'learning', 'Can I make an appointment?', 'Можно записаться на прием?', '["Можно записаться на прием?", "Можно вызвать врача?", "Можно купить лекарства?", "Можно пройти обследование?"]', None, 'Просьба записи к врачу 📋', 6),
        
        (7, 'practice', 'Как сказать что плохо себя чувствуешь?', 'I don\'t feel well', '["I don\'t feel well", "I feel great", "I\'m tired", "I\'m hungry"]', None, 'I don\'t feel well - жалоба на самочувствие 😷', 7),
        (7, 'practice', 'Как описать головную боль?', 'I have a headache', '["I have a headache", "I have a stomachache", "I have a sore throat", "I have a toothache"]', None, 'I have a... - описание симптомов боли 🩺', 8),
        (7, 'practice', 'Как попросить врача?', 'I need a doctor', '["I need a doctor", "I need help", "I need medicine", "I need rest"]', None, 'I need a doctor - просьба медицинской помощи 👨‍⚕️', 9),
        (7, 'practice', 'Как спросить где аптека?', 'Where is the pharmacy?', '["Where is the pharmacy?", "Where is the hospital?", "Where is the clinic?", "Where is the dentist?"]', None, 'Where is the pharmacy? - вопрос о местоположении 🏪', 10),
        (7, 'practice', 'Как сообщить об аллергии?', 'I\'m allergic to...', '["I\'m allergic to...", "I\'m not allergic", "I have high blood pressure", "I have diabetes"]', None, 'I\'m allergic to... - важная медицинская информация ⚠️', 11),
        
        # Урок 8: Деньги и шопинг
        (8, 'learning', 'How much does it cost?', 'Сколько это стоит?', '["Сколько это стоит?", "Что это?", "Где это сделано?", "Из чего это сделано?"]', None, 'Вопрос о цене товара 🏷️', 1),
        (8, 'learning', 'Do you have a discount?', 'У вас есть скидка?', '["У вас есть скидка?", "У вас есть размер побольше?", "У вас есть другой цвет?", "У вас есть гарантия?"]', None, 'Вопрос о скидках 💰', 2),
        (8, 'learning', 'I\'d like to try it on', 'Я бы хотел примерить', '["Я бы хотел примерить", "Я бы хотел купить", "Я бы хотел вернуть", "Я бы хотел обменять"]', None, 'Просьба примерить одежду 👕', 3),
        (8, 'learning', 'Where can I pay?', 'Где я могу оплатить?', '["Где я могу оплатить?", "Где примерочная?", "Где выход?", "Где лифт?"]', None, 'Вопрос о кассе 💳', 4),
        (8, 'learning', 'This is too expensive', 'Это слишком дорого', '["Это слишком дорого", "Это дешево", "Это хорошая цена", "Это нормальная цена"]', None, 'Комментарий о цене 💸', 5),
        (8, 'learning', 'I\'ll take it', 'Я беру это', '["Я беру это", "Я подумаю", "Я не беру", "Я вернусь позже"]', None, 'Решение о покупке 🛍️', 6),
        
        (8, 'practice', 'Как спросить цену товара?', 'How much does it cost?', '["How much does it cost?", "What is it?", "Where is it made?", "What is it made of?"]', None, 'How much does it cost? - вопрос о стоимости 💵', 7),
        (8, 'practice', 'Как спросить о скидке?', 'Do you have a discount?', '["Do you have a discount?", "Do you have a larger size?", "Do you have a different color?", "Do you have a warranty?"]', None, 'Do you have a discount? - вопрос о скидках 🎁', 8),
        (8, 'practice', 'Как попросить примерить?', 'I\'d like to try it on', '["I\'d like to try it on", "I\'d like to buy it", "I\'d like to return it", "I\'d like to exchange it"]', None, 'I\'d like to try it on - просьба примерить 👚', 9),
        (8, 'practice', 'Как спросить где касса?', 'Where can I pay?', '["Where can I pay?", "Where is the fitting room?", "Where is the exit?", "Where is the elevator?"]', None, 'Where can I pay? - вопрос об оплате 🧾', 10),
        (8, 'practice', 'Как сказать что дорого?', 'This is too expensive', '["This is too expensive", "This is cheap", "This is a good price", "This is a normal price"]', None, 'This is too expensive - комментарий о высокой цене 💎', 11),
        
        # Урок 9: Хобби и увлечения
        (9, 'learning', 'I enjoy reading books', 'Мне нравится читать книги', '["Мне нравится читать книги", "Мне нравится смотреть фильмы", "Мне нравится слушать музыку", "Мне нравится готовить"]', None, 'Рассказ о хобби 📚', 1),
        (9, 'learning', 'What are your hobbies?', 'Какие у тебя хобби?', '["Какие у тебя хобби?", "Где ты работаешь?", "Сколько тебе лет?", "Где ты живешь?"]', None, 'Вопрос об увлечениях 🎨', 2),
        (9, 'learning', 'I play the guitar', 'Я играю на гитаре', '["Я играю на гитаре", "Я играю на пианино", "Я играю на скрипке", "Я играю на барабанах"]', None, 'Рассказ о музыкальном хобби 🎸', 3),
        (9, 'learning', 'I love traveling', 'Я обожаю путешествовать', '["Я обожаю путешествовать", "Я ненавижу путешествовать", "Я редко путешествую", "Я никогда не путешествую"]', None, 'Выражение любви к путешествиям ✈️', 4),
        (9, 'learning', 'Let\'s go hiking', 'Давай пойдем в поход', '["Давай пойдем в поход", "Давай пойдем в кино", "Давай пойдем в кафе", "Давай пойдем в музей"]', None, 'Предложение активного отдыха 🏞️', 5),
        (9, 'learning', 'I\'m into photography', 'Я увлекаюсь фотографией', '["Я увлекаюсь фотографией", "Я увлекаюсь живописью", "Я увлекаюсь спортом", "Я увлекаюсь кулинарией"]', None, 'Рассказ о серьезном увлечении 📷', 6),
        
        (9, 'practice', 'Как сказать что нравится читать?', 'I enjoy reading books', '["I enjoy reading books", "I enjoy watching movies", "I enjoy listening to music", "I enjoy cooking"]', None, 'I enjoy... - выражение удовольствия от хобби 😊', 7),
        (9, 'practice', 'Как спросить о хобби?', 'What are your hobbies?', '["What are your hobbies?", "Where do you work?", "How old are you?", "Where do you live?"]', None, 'What are your hobbies? - вопрос об увлечениях 🎯', 8),
        (9, 'practice', 'Как сказать что играешь на гитаре?', 'I play the guitar', '["I play the guitar", "I play the piano", "I play the violin", "I play the drums"]', None, 'I play the... - рассказ о музыкальном инструменте 🎵', 9),
        (9, 'practice', 'Как выразить любовь к путешествиям?', 'I love traveling', '["I love traveling", "I hate traveling", "I rarely travel", "I never travel"]', None, 'I love traveling - выражение страсти к путешествиям 🌎', 10),
        (9, 'practice', 'Как предложить поход?', 'Let\'s go hiking', '["Let\'s go hiking", "Let\'s go to the movies", "Let\'s go to a cafe", "Let\'s go to a museum"]', None, 'Let\'s go... - предложение активности 🥾', 11),
        
        # Урок 10: Культура
        (10, 'learning', 'Cheers!', 'За здоровье!', '["За здоровье!", "Удачи!", "С праздником!", "С днем рождения!"]', None, 'Тост за здоровье 🥂', 1),
        (10, 'learning', 'That\'s interesting!', 'Это интересно!', '["Это интересно!", "Это скучно!", "Это странно!", "Это весело!"]', None, 'Выражение интереса 🤔', 2),
        (10, 'learning', 'What a beautiful tradition!', 'Какая красивая традиция!', '["Какая красивая традиция!", "Какая странная традиция!", "Какая старая традиция!", "Какая новая традиция!"]', None, 'Комплимент традиции 🎎', 3),
        (10, 'learning', 'I respect your culture', 'Я уважаю вашу культуру', '["Я уважаю вашу культуру", "Я не понимаю вашу культуру", "Мне нравится ваша культура", "Мне не нравится ваша культура"]', None, 'Выражение уважения к культуре 🙏', 4),
        (10, 'learning', 'Could you explain this custom?', 'Не могли бы вы объяснить этот обычай?', '["Не могли бы вы объяснить этот обычай?", "Не могли бы вы помочь?", "Не могли бы вы показать?", "Не могли бы вы рассказать?"]', None, 'Просьба объяснить традицию 📖', 5),
        (10, 'learning', 'This is different from my country', 'Это отличается от моей страны', '["Это отличается от моей страны", "Это похоже на мою страну", "Это лучше чем в моей стране", "Это хуже чем в моей стране"]', None, 'Сравнение культур 🌍', 6),
        
        (10, 'practice', 'Как сказать тост "За здоровье"?', 'Cheers!', '["Cheers!", "Good luck!", "Happy holiday!", "Happy birthday!"]', None, 'Cheers! - популярный тост в англоязычных странах 🍻', 7),
        (10, 'practice', 'Как выразить интерес?', 'That\'s interesting!', '["That\'s interesting!", "That\'s boring!", "That\'s weird!", "That\'s fun!"]', None, 'That\'s interesting! - выражение заинтересованности 🔍', 8),
        (10, 'practice', 'Как сделать комплимент традиции?', 'What a beautiful tradition!', '["What a beautiful tradition!", "What a strange tradition!", "What an old tradition!", "What a new tradition!"]', None, 'What a beautiful tradition! - комплимент культуре 🎊', 9),
        (10, 'practice', 'Как выразить уважение к культуре?', 'I respect your culture', '["I respect your culture", "I don\'t understand your culture", "I like your culture", "I don\'t like your culture"]', None, 'I respect your culture - выражение уважения 🌟', 10),
        (10, 'practice', 'Как попросить объяснить обычай?', 'Could you explain this custom?', '["Could you explain this custom?", "Could you help me?", "Could you show me?", "Could you tell me?"]', None, 'Could you explain... - вежливая просьба объяснить 🗣️', 11),
    ]
    
    for exercise in exercises_data:
        cursor.execute('''
            INSERT OR IGNORE INTO exercises 
            (lesson_id, type, question, correct_answer, options, audio_file, explanation, order_index)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', exercise)
    
    # Добавляем тестовых пользователей
    test_users = [
        ('тестовый', 'test@example.com', 'password123', 150, 7),
        ('мария', 'maria@example.com', 'password123', 450, 12),
        ('иван', 'ivan@example.com', 'password123', 890, 25),
        ('анна', 'anna@example.com', 'password123', 120, 3),
        ('сергей', 'sergey@example.com', 'password123', 1200, 45),
    ]
    
    for username, email, password, xp, streak in test_users:
        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        cursor.execute('''
            INSERT OR IGNORE INTO users (username, email, password_hash, xp, streak)
            VALUES (?, ?, ?, ?, ?)
        ''', (username, email, password_hash, xp, streak))
    
    conn.commit()
    conn.close()
    print("База данных успешно инициализирована!")

if __name__ == '__main__':
    init_database()