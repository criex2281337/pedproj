from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
import sqlite3
import bcrypt
from datetime import datetime, timedelta
import json
import os
import random
import functools
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your-secret-key-here-change-in-production'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=30)

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def log_debug(message):
    """Вывод дебаг сообщений в консоль Flask"""
    print(f"🔍 [DEBUG] {datetime.now().strftime('%H:%M:%S')} - {message}")

# Главная страница
@app.route('/')
def index():
    log_debug("Главная страница запрошена")
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

def admin_required(f):
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT is_admin FROM users WHERE id = ?', (session['user_id'],))
        user = cursor.fetchone()
        conn.close()
        
        if not user or not user['is_admin']:
            flash('Доступ запрещен. Требуются права администратора.')
            return redirect(url_for('dashboard'))
        
        return f(*args, **kwargs)
    return decorated_function

def active_user_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT is_active FROM users WHERE id = ?', (session['user_id'],))
        user = cursor.fetchone()
        conn.close()
        
        if not user or not user['is_active']:
            session.clear()
            flash('Ваш аккаунт заблокирован. Обратитесь к администратору.')
            return redirect(url_for('login'))
        
        return f(*args, **kwargs)
    return decorated_function

# Регистрация
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        native_language = request.form.get('native_language', 'Русский')
        target_language = request.form.get('target_language', 'Английский')
        
        log_debug(f"Попытка регистрации: {username}, {email}")
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Проверяем, существует ли пользователь
        cursor.execute('SELECT id FROM users WHERE username = ? OR email = ?', (username, email))
        if cursor.fetchone():
            flash('Имя пользователя или email уже существуют')
            log_debug(f"Регистрация провалилась: пользователь существует")
            return render_template('auth/register.html')
        
        # Хешируем пароль
        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        
        # Создаем пользователя
        cursor.execute('''
            INSERT INTO users (username, email, password_hash, native_language, target_language)
            VALUES (?, ?, ?, ?, ?)
        ''', (username, email, password_hash, native_language, target_language))
        
        conn.commit()
        user_id = cursor.lastrowid
        conn.close()
        
        session['user_id'] = user_id
        session['username'] = username
        flash('Регистрация прошла успешно!')
        log_debug(f"Успешная регистрация: {username}, ID: {user_id}")
        return redirect(url_for('dashboard'))
    
    log_debug("Отображение формы регистрации")
    return render_template('auth/register.html')

# Вход
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        log_debug(f"Попытка входа: {username}")
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
        user = cursor.fetchone()
        
        if user and bcrypt.checkpw(password.encode('utf-8'), user['password_hash']):
            # ПРОВЕРКА АКТИВНОСТИ ПОЛЬЗОВАТЕЛЯ - ДОБАВИТЬ ЭТО
            if not user['is_active']:
                flash('Ваш аккаунт заблокирован. Обратитесь к администратору.')
                log_debug(f"Попытка входа в заблокированный аккаунт: {username}")
                conn.close()
                return render_template('auth/login.html')
            
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['xp'] = user['xp']
            session['is_admin'] = user['is_admin']
            
            # Обновляем последний вход и проверяем стрик
            today = datetime.now().date()
            last_login_str = user['last_login']
            
            if last_login_str:
                try:
                    last_login = datetime.strptime(last_login_str, '%Y-%m-%d').date()
                    days_diff = (today - last_login).days
                    if days_diff == 1:
                        new_streak = user['streak'] + 1
                    elif days_diff > 1:
                        new_streak = 1
                    else:
                        new_streak = user['streak']
                except:
                    new_streak = 1
            else:
                new_streak = 1
            
            cursor.execute('''
                UPDATE users SET last_login = ?, streak = ? WHERE id = ?
            ''', (today.isoformat(), new_streak, user['id']))
            conn.commit()
            
            flash('Вход выполнен успешно!')
            log_debug(f"Успешный вход: {username}, streak: {new_streak}, admin: {user['is_admin']}")
            return redirect(url_for('dashboard'))
        else:
            flash('Неверное имя пользователя или пароль')
            log_debug(f"Неудачный вход: {username}")
        
        conn.close()
    
    log_debug("Отображение формы входа")
    return render_template('auth/login.html')

# Выход
@app.route('/logout')
def logout():
    username = session.get('username', 'Unknown')
    session.clear()
    log_debug(f"Выход пользователя: {username}")
    return redirect(url_for('index'))

# Дашборд
@app.route('/dashboard')
@active_user_required
def dashboard():
    if 'user_id' not in session:
        log_debug("Попытка доступа к дашборду без авторизации")
        return redirect(url_for('login'))
    
    log_debug(f"Дашборд запрошен пользователем: {session['username']}")
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Получаем данные пользователя
    cursor.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
    user = cursor.fetchone()
    
    # Получаем прогресс
    cursor.execute('''
        SELECT l.*, up.completed, up.score 
        FROM lessons l 
        LEFT JOIN user_progress up ON l.id = up.lesson_id AND up.user_id = ?
        WHERE l.language_id = 1
        ORDER BY l.order_index
    ''', (session['user_id'],))
    lessons = cursor.fetchall()
    
    # Определяем доступность уроков
    lessons_with_access = []
    next_lesson = None
    all_previous_completed = True  # Флаг что все предыдущие уроки завершены
    
    for i, lesson in enumerate(lessons):
        lesson_dict = dict(lesson)
        
        # Урок доступен, если все предыдущие завершены
        lesson_dict['accessible'] = all_previous_completed
        
        # Если текущий урок не завершен и доступен - это следующий урок
        if not lesson_dict['completed'] and lesson_dict['accessible'] and next_lesson is None:
            next_lesson = lesson_dict
        
        # Если текущий урок не завершен, то следующие будут недоступны
        if not lesson_dict['completed']:
            all_previous_completed = False
        
        lessons_with_access.append(lesson_dict)
    
    # Считаем завершенные уроки
    completed_lessons = sum(1 for lesson in lessons if lesson['completed'])
    
    # Получаем лидерборд
    cursor.execute('''
        SELECT username, xp, streak FROM users 
        ORDER BY xp DESC 
        LIMIT 10
    ''')
    leaderboard = cursor.fetchall()
    
    conn.close()
    
    log_debug(f"Дашборд: {completed_lessons}/{len(lessons)} уроков завершено, следующий урок: {next_lesson['id'] if next_lesson else 'нет'}")
    
    return render_template('dashboard.html', 
                         user=user, 
                         lessons=lessons_with_access, 
                         leaderboard=leaderboard,
                         next_lesson=next_lesson,
                         completed_lessons=completed_lessons)

# Список уроков
@app.route('/lessons')
@active_user_required
def lessons_list():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    log_debug(f"Список уроков запрошен: {session['username']}")
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
    user = cursor.fetchone()
    
    cursor.execute('''
        SELECT l.*, up.completed, up.score 
        FROM lessons l 
        LEFT JOIN user_progress up ON l.id = up.lesson_id AND up.user_id = ?
        WHERE l.language_id = 1
        ORDER BY l.order_index
    ''', (session['user_id'],))
    lessons = cursor.fetchall()
    
    # Считаем завершенные уроки
    completed_lessons = sum(1 for lesson in lessons if lesson['completed'])
    
    # Определяем, какие уроки доступны
    lessons_with_access = []
    next_lesson_available = True
    
    for i, lesson in enumerate(lessons):
        lesson_dict = dict(lesson)
        
        # Первый урок всегда доступен
        if i == 0:
            lesson_dict['accessible'] = True
        else:
            # Урок доступен, если предыдущий завершен
            previous_lesson = lessons[i-1]
            lesson_dict['accessible'] = previous_lesson['completed']
        
        lessons_with_access.append(lesson_dict)
    
    conn.close()
    
    log_debug(f"Уроки: найдено {len(lessons)} уроков, завершено {completed_lessons}")
    
    return render_template('lessons/list.html', 
                         lessons=lessons_with_access, 
                         user=user,
                         completed_lessons=completed_lessons)

# Практика урока
@app.route('/lesson/<int:lesson_id>')
@active_user_required
def lesson_practice(lesson_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    log_debug(f"Начало урока {lesson_id} пользователем: {session['username']}")
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM lessons WHERE id = ?', (lesson_id,))
    lesson = cursor.fetchone()
    
    if not lesson:
        flash('Урок не найден')
        log_debug(f"Урок {lesson_id} не найден")
        return redirect(url_for('lessons_list'))
    
    # Проверяем доступ к уроку
    if lesson_id > 1:  # Все уроки кроме первого
        # Проверяем, завершен ли предыдущий урок
        cursor.execute('''
            SELECT up.completed 
            FROM user_progress up 
            WHERE up.user_id = ? AND up.lesson_id = ?
        ''', (session['user_id'], lesson_id - 1))
        previous_lesson_progress = cursor.fetchone()
        
        if not previous_lesson_progress or not previous_lesson_progress['completed']:
            flash('Сначала завершите предыдущий урок')
            log_debug(f"Попытка доступа к уроку {lesson_id} без завершения предыдущего")
            return redirect(url_for('lessons_list'))
    
    cursor.execute('''
        SELECT * FROM exercises 
        WHERE lesson_id = ? 
        ORDER BY order_index
    ''', (lesson_id,))
    exercises = cursor.fetchall()
    
    # Разделяем упражнения на обучение и практику
    learning_exercises = []
    practice_exercises = []
    
    for ex in exercises:
        exercise_dict = dict(ex)
        if ex['options']:
            try:
                options = json.loads(ex['options'])
                # Перемешиваем варианты ответов для практических упражнений
                if ex['type'] == 'practice':
                    correct_answer = exercise_dict['correct_answer']
                    # Создаем копию и перемешиваем, но запоминаем правильный ответ
                    shuffled_options = options.copy()
                    random.shuffle(shuffled_options)
                    exercise_dict['options'] = shuffled_options
                    exercise_dict['correct_answer'] = correct_answer  # Сохраняем правильный ответ
                else:
                    exercise_dict['options'] = options
            except:
                exercise_dict['options'] = []
        else:
            exercise_dict['options'] = []
        
        if ex['type'] == 'learning':
            learning_exercises.append(exercise_dict)
        else:
            practice_exercises.append(exercise_dict)
    
    conn.close()
    
    # Логируем информацию об упражнениях
    log_debug(f"Урок {lesson_id}: {len(learning_exercises)} обучающих, {len(practice_exercises)} практических упражнений")
    
    return render_template('lessons/practice.html', 
                         lesson=lesson, 
                         learning_exercises=learning_exercises,
                         practice_exercises=practice_exercises)

# Проверка ответов
@app.route('/check_answer', methods=['POST'])
def check_answer():
    if 'user_id' not in session:
        log_debug("Попытка проверки ответа без авторизации")
        return jsonify({'error': 'Не авторизован'}), 401
    
    data = request.get_json()
    exercise_id = data.get('exercise_id')
    user_answer = data.get('user_answer', '')
    
    log_debug(f"Проверка ответа: exercise_id={exercise_id}, user_answer='{user_answer}', user={session['username']}")
    
    if not exercise_id:
        log_debug("Ошибка: exercise_id отсутствует")
        return jsonify({'error': 'ID упражнения обязателен'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM exercises WHERE id = ?', (exercise_id,))
    exercise = cursor.fetchone()
    
    if not exercise:
        log_debug(f"Ошибка: упражнение {exercise_id} не найдено")
        return jsonify({'error': 'Упражнение не найдено'}), 404
    
    # Для упражнений типа multiple_choice сравниваем текст
    is_correct = user_answer.strip() == exercise['correct_answer'].strip()
    
    log_debug(f"Результат проверки: {'ПРАВИЛЬНО' if is_correct else 'НЕПРАВИЛЬНО'}, правильный ответ: '{exercise['correct_answer']}'")
    
    # Сохраняем ответ пользователя
    cursor.execute('''
        INSERT INTO user_answers (user_id, exercise_id, user_answer, is_correct)
        VALUES (?, ?, ?, ?)
    ''', (session['user_id'], exercise_id, user_answer, is_correct))
    
    conn.commit()
    conn.close()
    
    return jsonify({
        'is_correct': is_correct,
        'correct_answer': exercise['correct_answer'],
        'explanation': exercise['explanation'] or ''
    })

# Завершение урока
# Завершение урока
@app.route('/complete_lesson', methods=['POST'])
def complete_lesson():
    if 'user_id' not in session:
        return jsonify({'error': 'Не авторизован'}), 401
    
    data = request.get_json()
    lesson_id = data.get('lesson_id')
    score = data.get('score', 0)
    correct_answers_count = data.get('correct_answers_count', 0)  # Количество правильных ответов
    total_exercises = data.get('total_exercises', 0)  # Общее количество упражнений
    
    log_debug(f"Завершение урока: lesson_id={lesson_id}, score={score}, correct_answers={correct_answers_count}/{total_exercises}, user={session['username']}")
    
    if not lesson_id:
        return jsonify({'error': 'ID урока обязателен'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Получаем награду за урок
    cursor.execute('SELECT xp_reward FROM lessons WHERE id = ?', (lesson_id,))
    lesson = cursor.fetchone()
    if not lesson:
        log_debug(f"Ошибка: урок {lesson_id} не найден")
        return jsonify({'error': 'Урок не найден'}), 404
    
    # Проверяем, проходил ли пользователь урок ранее
    cursor.execute('SELECT * FROM user_progress WHERE user_id = ? AND lesson_id = ?', 
                  (session['user_id'], lesson_id))
    existing_progress = cursor.fetchone()
    
    if existing_progress:
        conn.close()
        return jsonify({
            'success': True,
            'completed': True,
            'already_completed': True,
            'previous_score': existing_progress['score'],
            'previous_xp_earned': 0,
            'total_xp': session.get('xp', 0),
            'message': f'Вы уже проходили этот урок ранее. Ваш результат: {existing_progress["score"]}%'
        })
    
    # РАСЧЕТ XP ЗА КАЖДЫЙ ПРАВИЛЬНЫЙ ОТВЕТ
    base_xp_per_correct = 5  # Базовое XP за каждый правильный ответ
    xp_earned = correct_answers_count * base_xp_per_correct
    
    # Бонус за полное прохождение (все ответы правильные)
    if correct_answers_count == total_exercises:
        xp_earned += 10  # Дополнительный бонус
        log_debug(f"Бонус за полное прохождение: +10 XP")
    
    # Минимальное XP даже при плохом результате
    if xp_earned == 0 and total_exercises > 0:
        xp_earned = 2  # Минимальная награда за попытку
    
    log_debug(f"Начислено XP: {xp_earned} (за {correct_answers_count} правильных ответов)")
    
    # Сохраняем прогресс
    cursor.execute('''
        INSERT INTO user_progress (user_id, lesson_id, completed, score, completed_at, attempts)
        VALUES (?, ?, TRUE, ?, datetime('now'), 1)
    ''', (session['user_id'], lesson_id, score))
    
    # Начисляем XP
    cursor.execute('''
        UPDATE users SET xp = xp + ? WHERE id = ?
    ''', (xp_earned, session['user_id']))
    
    conn.commit()
    
    # Получаем обновленные данные
    cursor.execute('SELECT xp FROM users WHERE id = ?', (session['user_id'],))
    user = cursor.fetchone()
    
    conn.close()
    
    session['xp'] = user['xp']
    
    # Формируем сообщение
    if correct_answers_count == total_exercises:
        message = f"🎉 Идеально! Все ответы правильные! +{xp_earned} XP"
    elif correct_answers_count > 0:
        message = f"✅ Правильных ответов: {correct_answers_count}/{total_exercises} +{xp_earned} XP"
    else:
        message = f"📝 Правильных ответов: 0/{total_exercises}. Попробуйте другой урок!"
    
    return jsonify({
        'success': True,
        'completed': True,
        'already_completed': False,
        'xp_earned': xp_earned,
        'total_xp': user['xp'],
        'score': score,
        'correct_answers_count': correct_answers_count,
        'total_exercises': total_exercises,
        'message': message
    })

@app.route('/profile')
@active_user_required
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    log_debug(f"Профиль запрошен: {session['username']}")
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],))
    user = cursor.fetchone()
    
    if not user:
        flash('Пользователь не найден')
        return redirect(url_for('login'))
    
    cursor.execute('''
        SELECT COUNT(*) as lessons_completed 
        FROM user_progress 
        WHERE user_id = ? AND completed = TRUE
    ''', (session['user_id'],))
    stats = cursor.fetchone()
    
    cursor.execute('''
        SELECT COUNT(*) as exercises_completed 
        FROM user_answers 
        WHERE user_id = ?
    ''', (session['user_id'],))
    exercises_stats = cursor.fetchone()
    
    cursor.execute('''
        SELECT COUNT(*) as correct_answers 
        FROM user_answers 
        WHERE user_id = ? AND is_correct = TRUE
    ''', (session['user_id'],))
    correct_stats = cursor.fetchone()
    
    cursor.execute('''
        SELECT l.title, up.score, up.completed_at 
        FROM user_progress up 
        JOIN lessons l ON up.lesson_id = l.id 
        WHERE up.user_id = ? AND up.completed = TRUE 
        ORDER BY up.completed_at DESC 
        LIMIT 5
    ''', (session['user_id'],))
    recent_lessons = cursor.fetchall()
    
    cursor.execute('''
        SELECT l.title, up.score, up.completed_at
        FROM user_progress up
        JOIN lessons l ON up.lesson_id = l.id
        WHERE up.user_id = ? AND up.completed = TRUE
        ORDER BY up.completed_at DESC
    ''', (session['user_id'],))
    all_completed_lessons = cursor.fetchall()
    
    conn.close()
    
    log_debug(f"Статистика профиля: {stats['lessons_completed']} уроков, {exercises_stats['exercises_completed']} упражнений")
    
    return render_template('profile.html', 
                         user=user, 
                         stats=stats,
                         exercises_stats=exercises_stats,
                         correct_stats=correct_stats,
                         recent_lessons=recent_lessons,
                         all_completed_lessons=all_completed_lessons)

@app.route('/api/user_stats')
def user_stats():
    if 'user_id' not in session:
        return jsonify({'error': 'Не авторизован'}), 401
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) as total_lessons FROM lessons WHERE language_id = 1')
    total_lessons = cursor.fetchone()['total_lessons']
    
    cursor.execute('SELECT COUNT(*) as completed_lessons FROM user_progress WHERE user_id = ? AND completed = TRUE', (session['user_id'],))
    completed_lessons = cursor.fetchone()['completed_lessons']
    
    cursor.execute('SELECT COUNT(*) as total_exercises FROM user_answers WHERE user_id = ?', (session['user_id'],))
    total_exercises = cursor.fetchone()['total_exercises']
    
    cursor.execute('SELECT COUNT(*) as correct_exercises FROM user_answers WHERE user_id = ? AND is_correct = TRUE', (session['user_id'],))
    correct_exercises = cursor.fetchone()['correct_exercises']
    
    cursor.execute('SELECT SUM(xp) as total_xp FROM users WHERE id = ?', (session['user_id'],))
    total_xp = cursor.fetchone()['total_xp'] or 0
    
    cursor.execute('SELECT streak FROM users WHERE id = ?', (session['user_id'],))
    streak = cursor.fetchone()['streak']
    
    conn.close()
    
    accuracy = (correct_exercises / total_exercises * 100) if total_exercises > 0 else 0
    
    return jsonify({
        'total_lessons': total_lessons,
        'completed_lessons': completed_lessons,
        'total_exercises': total_exercises,
        'correct_exercises': correct_exercises,
        'accuracy': round(accuracy, 1),
        'total_xp': total_xp,
        'streak': streak
    })

@app.route('/debug_js')
def debug_js():
    log_debug("Запрос дебаг страницы JavaScript")
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Debug JavaScript</title>
        <style>
            .option-btn { padding: 20px; margin: 10px; border: 2px solid #ccc; cursor: pointer; }
            .selected { background: green; color: white; }
        </style>
    </head>
    <body>
        <h1>Тест JavaScript</h1>
        <div class="option-btn" onclick="selectOption(this)">Вариант 1</div>
        <div class="option-btn" onclick="selectOption(this)">Вариант 2</div>
        <div class="option-btn" onclick="selectOption(this)">Вариант 3</div>
        <button onclick="checkAnswer()">Проверить ответ</button>
        
        <script>
            function selectOption(btn) {
                // Убираем выделение у всех
                document.querySelectorAll('.option-btn').forEach(b => {
                    b.classList.remove('selected');
                });
                // Выбираем текущую
                btn.classList.add('selected');
                console.log('Выбран:', btn.textContent);
            }
            
            function checkAnswer() {
                const selected = document.querySelector('.option-btn.selected');
                if (!selected) {
                    alert('Выберите вариант!');
                    return;
                }
                alert('Выбран: ' + selected.textContent);
            }
            
            console.log('JavaScript работает!');
        </script>
    </body>
    </html>
    '''

@app.route('/about')
def about():
    log_debug("Страница 'О проекте' запрошена")
    return render_template('about.html')

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    conn = get_db_connection()
    conn.close()
    return render_template('500.html'), 500

@app.route('/health')
def health_check():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT 1')
        conn.close()
        return jsonify({'status': 'healthy', 'database': 'connected'})
    except Exception as e:
        return jsonify({'status': 'unhealthy', 'error': str(e)}), 500

@app.route('/admin')
@admin_required
def admin_dashboard():
    log_debug(f"Админ панель запрошена пользователем: {session['username']}")
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Статистика
    cursor.execute('SELECT COUNT(*) as total_users FROM users')
    total_users = cursor.fetchone()['total_users']
    
    cursor.execute('SELECT COUNT(*) as active_users FROM users WHERE is_active = TRUE')
    active_users = cursor.fetchone()['active_users']
    
    cursor.execute('SELECT COUNT(*) as total_lessons FROM lessons')
    total_lessons = cursor.fetchone()['total_lessons']
    
    cursor.execute('SELECT COUNT(*) as total_exercises FROM exercises')
    total_exercises = cursor.fetchone()['total_exercises']
    
    # Последние пользователи
    cursor.execute('''
        SELECT id, username, email, created_at, is_active, is_admin 
        FROM users 
        ORDER BY created_at DESC 
        LIMIT 5
    ''')
    recent_users = cursor.fetchall()
    
    # Активность
    cursor.execute('''
        SELECT u.username, up.completed_at, l.title 
        FROM user_progress up 
        JOIN users u ON up.user_id = u.id 
        JOIN lessons l ON up.lesson_id = l.id 
        WHERE up.completed = TRUE 
        ORDER BY up.completed_at DESC 
        LIMIT 10
    ''')
    recent_activity = cursor.fetchall()
    
    conn.close()
    
    return render_template('admin/dashboard.html',
                         total_users=total_users,
                         active_users=active_users,
                         total_lessons=total_lessons,
                         total_exercises=total_exercises,
                         recent_users=recent_users,
                         recent_activity=recent_activity)

# Управление пользователями
@app.route('/admin/users')
@admin_required
def admin_users():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, username, email, created_at, last_login, 
               xp, streak, is_active, is_admin 
        FROM users 
        ORDER BY created_at DESC
    ''')
    users = cursor.fetchall()
    
    conn.close()
    
    return render_template('admin/users.html', users=users)

# Блокировка/разблокировка пользователя
@app.route('/admin/user/<int:user_id>/toggle', methods=['POST'])
@admin_required
def toggle_user(user_id):
    if user_id == session['user_id']:
        return jsonify({'error': 'Нельзя изменить статус своего аккаунта'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT is_active FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    
    if not user:
        return jsonify({'error': 'Пользователь не найден'}), 404
    
    new_status = not user['is_active']
    cursor.execute('UPDATE users SET is_active = ? WHERE id = ?', (new_status, user_id))
    conn.commit()
    
    cursor.execute('SELECT username, is_active FROM users WHERE id = ?', (user_id,))
    updated_user = cursor.fetchone()
    conn.close()
    
    log_debug(f"Статус пользователя {updated_user['username']} изменен на: {'активен' if new_status else 'заблокирован'}")
    
    return jsonify({
        'success': True,
        'is_active': new_status,
        'message': f"Пользователь {updated_user['username']} {'разблокирован' if new_status else 'заблокирован'}"
    })

# Назначение/снятие прав администратора
@app.route('/admin/user/<int:user_id>/admin', methods=['POST'])
@admin_required
def toggle_admin(user_id):
    if user_id == session['user_id']:
        return jsonify({'error': 'Нельзя изменить права своего аккаунта'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT is_admin FROM users WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    
    if not user:
        return jsonify({'error': 'Пользователь не найден'}), 404
    
    new_admin_status = not user['is_admin']
    cursor.execute('UPDATE users SET is_admin = ? WHERE id = ?', (new_admin_status, user_id))
    conn.commit()
    
    cursor.execute('SELECT username, is_admin FROM users WHERE id = ?', (user_id,))
    updated_user = cursor.fetchone()
    conn.close()
    
    log_debug(f"Админ права пользователя {updated_user['username']} изменены на: {'админ' if new_admin_status else 'пользователь'}")
    
    return jsonify({
        'success': True,
        'is_admin': new_admin_status,
        'message': f"Права администратора {'выданы' if new_admin_status else 'отозваны'} для {updated_user['username']}"
    })

# Управление уроками
@app.route('/admin/lessons')
@admin_required
def admin_lessons():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT l.*, lang.name as language_name,
               COUNT(e.id) as exercise_count,
               COUNT(up.id) as completions
        FROM lessons l
        LEFT JOIN languages lang ON l.language_id = lang.id
        LEFT JOIN exercises e ON l.id = e.lesson_id
        LEFT JOIN user_progress up ON l.id = up.lesson_id AND up.completed = TRUE
        GROUP BY l.id
        ORDER BY l.level, l.order_index
    ''')
    lessons = cursor.fetchall()
    
    cursor.execute('SELECT id, name FROM languages')
    languages = cursor.fetchall()
    
    conn.close()
    
    return render_template('admin/lessons.html', 
                         lessons=lessons, 
                         languages=languages)

# Добавление нового урока
@app.route('/admin/lessons/add', methods=['POST'])
@admin_required
def add_lesson():
    data = request.get_json()
    
    required_fields = ['title', 'description', 'language_id', 'level', 'order_index', 'xp_reward']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'error': f'Поле {field} обязательно'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT INTO lessons (title, description, language_id, level, order_index, xp_reward)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (data['title'], data['description'], data['language_id'], 
              data['level'], data['order_index'], data['xp_reward']))
        
        lesson_id = cursor.lastrowid
        conn.commit()
        
        log_debug(f"Добавлен новый урок: {data['title']} (ID: {lesson_id})")
        
        return jsonify({
            'success': True,
            'lesson_id': lesson_id,
            'message': 'Урок успешно добавлен'
        })
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

# Получение данных урока для редактирования
@app.route('/admin/lesson/<int:lesson_id>')
@admin_required
def get_lesson(lesson_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM lessons WHERE id = ?', (lesson_id,))
    lesson = cursor.fetchone()
    
    conn.close()
    
    if not lesson:
        return jsonify({'success': False, 'error': 'Урок не найден'})
    
    return jsonify({
        'success': True,
        'data': {
            'id': lesson['id'],
            'title': lesson['title'],
            'description': lesson['description'],
            'language_id': lesson['language_id'],
            'level': lesson['level'],
            'order_index': lesson['order_index'],
            'xp_reward': lesson['xp_reward']
        }
    })

# Редактирование урока
@app.route('/admin/lessons/<int:lesson_id>/edit', methods=['POST'])
@admin_required
def edit_lesson(lesson_id):
    data = request.get_json()
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Получаем текущие данные урока
        cursor.execute('SELECT * FROM lessons WHERE id = ?', (lesson_id,))
        current_lesson = cursor.fetchone()
        
        if not current_lesson:
            return jsonify({'error': 'Урок не найден'}), 404
        
        cursor.execute('''
            UPDATE lessons 
            SET title = ?, description = ?, language_id = ?, level = ?, 
                order_index = ?, xp_reward = ?
            WHERE id = ?
        ''', (data['title'], data['description'], data['language_id'],
              data['level'], data['order_index'], data['xp_reward'], lesson_id))
        
        conn.commit()
        
        log_debug(f"Урок {lesson_id} отредактирован")
        
        return jsonify({
            'success': True,
            'message': 'Урок успешно обновлен'
        })
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

# Удаление урока
@app.route('/admin/lessons/<int:lesson_id>/delete', methods=['POST'])
@admin_required
def delete_lesson(lesson_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Получаем название урока для лога
        cursor.execute('SELECT title FROM lessons WHERE id = ?', (lesson_id,))
        lesson = cursor.fetchone()
        
        if not lesson:
            return jsonify({'error': 'Урок не найден'}), 404
        
        # Удаляем связанные упражнения и прогресс
        cursor.execute('DELETE FROM exercises WHERE lesson_id = ?', (lesson_id,))
        cursor.execute('DELETE FROM user_progress WHERE lesson_id = ?', (lesson_id,))
        cursor.execute('DELETE FROM lessons WHERE id = ?', (lesson_id,))
        
        conn.commit()
        
        log_debug(f"Урок удален: {lesson['title']} (ID: {lesson_id})")
        
        return jsonify({
            'success': True,
            'message': 'Урок и связанные данные удалены'
        })
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

# Получение данных упражнения для редактирования
@app.route('/admin/exercise/<int:exercise_id>')
@admin_required
def get_exercise(exercise_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM exercises WHERE id = ?', (exercise_id,))
    exercise = cursor.fetchone()
    
    conn.close()
    
    if not exercise:
        return jsonify({'success': False, 'error': 'Упражнение не найдено'})
    
    # Парсим JSON options
    options = []
    if exercise['options']:
        try:
            options = json.loads(exercise['options'])
        except:
            options = []
    
    return jsonify({
        'success': True,
        'data': {
            'id': exercise['id'],
            'lesson_id': exercise['lesson_id'],
            'type': exercise['type'],
            'question': exercise['question'],
            'correct_answer': exercise['correct_answer'],
            'options': options,
            'explanation': exercise['explanation'],
            'order_index': exercise['order_index']
        }
    })

# Редактирование упражнения
@app.route('/admin/exercises/<int:exercise_id>/edit', methods=['POST'])
@admin_required
def edit_exercise(exercise_id):
    data = request.get_json()
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Получаем текущие данные упражнения
        cursor.execute('SELECT * FROM exercises WHERE id = ?', (exercise_id,))
        current_exercise = cursor.fetchone()
        
        if not current_exercise:
            return jsonify({'error': 'Упражнение не найдено'}), 404
        
        # Преобразуем options в JSON
        options_json = json.dumps(data.get('options', [])) if data.get('options') else None
        
        cursor.execute('''
            UPDATE exercises 
            SET type = ?, question = ?, correct_answer = ?, 
                options = ?, explanation = ?, order_index = ?
            WHERE id = ?
        ''', (data['type'], data['question'], data['correct_answer'],
              options_json, data.get('explanation'), data['order_index'], exercise_id))
        
        conn.commit()
        
        log_debug(f"Упражнение {exercise_id} отредактировано")
        
        return jsonify({
            'success': True,
            'message': 'Упражнение успешно обновлено'
        })
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

# Управление упражнениями
@app.route('/admin/lessons/<int:lesson_id>/exercises')
@admin_required
def admin_exercises(lesson_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM lessons WHERE id = ?', (lesson_id,))
    lesson = cursor.fetchone()
    
    if not lesson:
        flash('Урок не найден')
        return redirect(url_for('admin_lessons'))
    
    cursor.execute('''
        SELECT * FROM exercises 
        WHERE lesson_id = ? 
        ORDER BY order_index
    ''', (lesson_id,))
    exercises = cursor.fetchall()
    
    # Парсим JSON options для каждого упражнения
    exercises_data = []
    for ex in exercises:
        exercise_dict = dict(ex)
        if ex['options']:
            try:
                exercise_dict['options'] = json.loads(ex['options'])
            except:
                exercise_dict['options'] = []
        else:
            exercise_dict['options'] = []
        exercises_data.append(exercise_dict)
    
    conn.close()
    
    return render_template('admin/exercises.html', 
                         lesson=lesson, 
                         exercises=exercises_data)

# Удаление упражнения
@app.route('/admin/exercises/<int:exercise_id>/delete', methods=['POST'])
@admin_required
def delete_exercise(exercise_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        # Получаем информацию об упражнении для лога
        cursor.execute('SELECT question FROM exercises WHERE id = ?', (exercise_id,))
        exercise = cursor.fetchone()
        
        if not exercise:
            return jsonify({'error': 'Упражнение не найдено'}), 404
        
        # Удаляем связанные ответы пользователей
        cursor.execute('DELETE FROM user_answers WHERE exercise_id = ?', (exercise_id,))
        # Удаляем упражнение
        cursor.execute('DELETE FROM exercises WHERE id = ?', (exercise_id,))
        
        conn.commit()
        
        log_debug(f"Упражнение удалено: {exercise['question']} (ID: {exercise_id})")
        
        return jsonify({
            'success': True,
            'message': 'Упражнение удалено'
        })
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

# Добавление упражнения
@app.route('/admin/exercises/add', methods=['POST'])
@admin_required
def add_exercise():
    data = request.get_json()
    
    required_fields = ['lesson_id', 'type', 'question', 'correct_answer', 'order_index']
    for field in required_fields:
        if not data.get(field):
            return jsonify({'error': f'Поле {field} обязательно'}), 400
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        options_json = json.dumps(data.get('options', [])) if data.get('options') else None
        
        cursor.execute('''
            INSERT INTO exercises (lesson_id, type, question, correct_answer, 
                                 options, explanation, order_index)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (data['lesson_id'], data['type'], data['question'], 
              data['correct_answer'], options_json, 
              data.get('explanation'), data['order_index']))
        
        exercise_id = cursor.lastrowid
        conn.commit()
        
        log_debug(f"Добавлено новое упражнение: {data['question']} (ID: {exercise_id})")
        
        return jsonify({
            'success': True,
            'exercise_id': exercise_id,
            'message': 'Упражнение успешно добавлено'
        })
        
    except Exception as e:
        conn.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

if __name__ == '__main__':
    if not os.path.exists('database.db'):
        print("Пожалуйста, сначала запустите init_db.py для инициализации базы данных")
    else:
        log_debug("Сервер Flask запускается...")
        app.run(debug=True, host='0.0.0.0', port=5000)
