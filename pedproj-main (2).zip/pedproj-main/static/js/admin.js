// Общие функции для админ-панели
document.addEventListener('DOMContentLoaded', function() {
    console.log('Админ панель загружена');
    
    // Закрытие модальных окон при клике вне их
    window.onclick = function(event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    }
    
    // Закрытие модальных окон на Escape
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                modal.style.display = 'none';
            });
        }
    });
});

// Функции для работы с уроками
function showAddExerciseModal(lessonId) {
    // Реализация добавления упражнений
    alert('Добавление упражнения для урока ' + lessonId);
}

// Утилиты
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU');
}

function showLoading(button) {
    const originalText = button.innerHTML;
    button.innerHTML = '<span class="loading">Загрузка...</span>';
    button.disabled = true;
    return originalText;
}

function hideLoading(button, originalText) {
    button.innerHTML = originalText;
    button.disabled = false;
}

// Уведомления
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 5000);
}